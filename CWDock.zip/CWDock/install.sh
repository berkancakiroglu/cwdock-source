#!/bin/bash
echo "..."
mkdir /opt/CWDock
cp -r appicons /opt/CWDock/appicons
cp appconf /opt/CWDock/appconf
cp dconf /opt/CWDock/dconf
cp style.css /opt/CWDock/style.css
cp CWDock /usr/bin/CWDock
chmod +x /usr/bin/CWDock
echo "ok"



