Auto Install
	sudo ./install.sh

Manuel Install
	copy files:
		/opt/CWDock/appicons
		/opt/CWDock/appconf
		/opt/CWDock/dconf
		/opt/CWDock/style.css
		/usr/bin/CWDock
	runnable file:
		chmod +x /usr/bin/CWDock

Autorun (Openbox)
	create file:
		Home Directory + /.config/openbox/autostart.sh

	add line:
		CWDock &




